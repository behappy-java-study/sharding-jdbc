package com.atguigu.shargingjdbcdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShargingJdbcDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
