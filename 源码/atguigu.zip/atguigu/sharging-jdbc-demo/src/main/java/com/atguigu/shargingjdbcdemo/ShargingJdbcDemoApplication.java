package com.atguigu.shargingjdbcdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShargingJdbcDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShargingJdbcDemoApplication.class, args);
    }

}
